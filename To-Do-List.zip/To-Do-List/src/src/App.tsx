import React, { useState } from 'react';

interface Task {
  id: number;
  content: string;
  completed: boolean;
}

const App: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [newTask, setNewTask] = useState('');

  const handleAddTask = () => {
    if (newTask.trim() === '') return;
    const task: Task = {
      id: Date.now(),
      content: newTask.trim(),
      completed: false
    };
    setTasks(prev => [...prev, task]);
    setNewTask('');
  };

  const toggleTaskCompletion = (id: number) => {
    setTasks(prev =>
      prev.map(task =>
        task.id === id ? { ...task, completed: !task.completed } : task
      )
    );
  };

  return (
    <div style={{ maxWidth: 400, margin: '2rem auto', fontFamily: 'Arial, sans-serif' }}>
      <h1>To-Do List</h1>
      <input
        type="text"
        placeholder="Digite uma nova tarefa"
        value={newTask}
        onChange={e => setNewTask(e.target.value)}
        onKeyDown={e => { if (e.key === 'Enter') handleAddTask(); }}
        style={{ width: '100%', padding: '8px', marginBottom: '10px', boxSizing: 'border-box' }}
      />
      <button onClick={handleAddTask} style={{ padding: '8px 12px', marginBottom: '20px' }}>
        Adicionar Tarefa
      </button>
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {tasks.map(task => (
          <li
            key={task.id}
            onClick={() => toggleTaskCompletion(task.id)}
            style={{
              cursor: 'pointer',
              padding: '8px',
              marginBottom: '4px',
              backgroundColor: task.completed ? '#d3ffd3' : '#f9f9f9',
              textDecoration: task.completed ? 'line-through' : 'none'
            }}
          >
            {task.content}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default App;
